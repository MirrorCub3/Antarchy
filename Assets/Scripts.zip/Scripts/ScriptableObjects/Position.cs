using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class Position : ScriptableObject // Joyce Mai
{
    public Vector3 postion;
}
